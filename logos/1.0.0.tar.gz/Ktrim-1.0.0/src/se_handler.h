/**
 * Author: Kun Sun (sunkun@szbl.ac.cn)
 * Date: Dec, 2019
 * This program is part of the Ktrim package
**/

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <omp.h>
#include "common.h"
using namespace std;

/*
 * use dynamic max_mismatch as the covered size can range from 3 to a large number such as 50,
 * here the maximum mismatch allowed is LEN/8
*/
bool check_mismatch_dynamic_SE( const string & s, unsigned int pos, const ktrim_param & kp ) {
	register unsigned int mis=0;
	register unsigned int i, len;
	len = s.length() - pos;
	if( len > kp.adapter_len )
	  len = kp.adapter_len;

	register unsigned int max_mismatch_dynamic = len >> 3;
	if( (max_mismatch_dynamic<<3) != len )
	  ++ max_mismatch_dynamic;

	const char * p = s.c_str();
	for( i=0; i!=len; ++i ) {
		if( p[pos+i] != kp.adapter_r1[i] ) {
			++ mis;
			if( mis > max_mismatch_dynamic )
			  return false;
		}
	}

	return true;
}

int process_se( const ktrim_param &kp ) {
	string *id1   = new string [READS_PER_BATCH];
	string *seq1  = new string [READS_PER_BATCH];
	string *qual1 = new string [READS_PER_BATCH];
	string unk;

	int *dropped	  = new int [ kp.thread ];
	int *real_adapter = new int [ kp.thread ];
	int *tail_adapter = new int [ kp.thread ];

	// buffer for storing the modified reads per thread
	char ** buffer1 = new char * [ kp.thread ];
	int  * b1stored = new int	 [ kp.thread ];

	for(unsigned int i=0; i!=kp.thread; ++i) {
		buffer1[i] = new char[ BUFFER_SIZE_PER_BATCH_READ ];
		dropped[i] = 0;
		real_adapter[i] = 0;
		tail_adapter[i] = 0;
	}

//	cerr << "Loading files ...\n";
    // deal with multiple input files
    vector<string> R1s;
    string fileName="";
    for(unsigned int i=0; kp.FASTQ1[i]!='\0'; ++i) {
        if( kp.FASTQ1[i] == FILE_SEPARATOR ) {
            R1s.push_back( fileName );
            cerr << "Add read 1 file: " << fileName << '\n';
            fileName.clear();
        } else {
            fileName += kp.FASTQ1[i];
        }
    }
    if( fileName.size() )   // in case there is a FILE_SEPARATOR at the end
        R1s.push_back( fileName );

    unsigned int totalFiles = R1s.size();
    cout << "\033[1;34mINFO: " << totalFiles << " paired fastq files will be loaded.\033[0m\n";

    string base = kp.outpre;
    base += ".read1.fq";
	ofstream fout1( base.c_str() );
	if( fout1.fail() ) {
		cout << "\033[1;31mError: write file failed!\033[0m\n";
		fout1.close();
		return 103;
	}

    ifstream fq1, fq2;
    register unsigned int line = 0;
    for( unsigned int fileCnt=0; fileCnt!=totalFiles; ++ fileCnt ) {
        fq1.open( R1s[fileCnt] );
        if( fq1.fail() ) {
            cout << "\033[1;31mError: open fastq file failed!\033[0m\n";
            fq1.close();
            fout1.close();
            return 104;
        }

        while( true ) {
            // get fastq reads
            unsigned int loaded = 0;
            while( true ) {
                getline( fq1, id1  [ loaded ] );
                if( fq1.eof() )break;
                getline( fq1, seq1 [ loaded ] );
                getline( fq1, unk );
                getline( fq1, qual1[ loaded ] );

                ++ loaded;
                if( loaded == READS_PER_BATCH )
                    break;
            }
            //cerr << "loaded: " << loaded << '\n';
            if( loaded == 0 )
                break;

            // start parallalization
            omp_set_num_threads( kp.thread );
            #pragma omp parallel
            {
                unsigned int tn = omp_get_thread_num();
                unsigned int start = loaded * tn / kp.thread;
                unsigned int end   = loaded * (tn+1) / kp.thread;

                // normalization
                b1stored[tn] = 0;

                register int i, j;
                register unsigned int last_seed;
                vector<unsigned int> seed;
                vector<unsigned int> :: iterator it;
                const char *p, *q;

                for( unsigned int ii=start; ii!=end; ++ii ) {
                    // quality control
                    p = qual1[ii].c_str();
                    for( i=qual1[ii].length()-1; i; --i ) {
                        if( p[i] >= kp.quality ) break;
                    }
                    ++ i;
                    if( i < kp.min_length ) { // not long enough
                        ++ dropped[ tn ];
                        continue;
                    }
                    seq1[ii].resize(  i );
                    qual1[ii].resize( i );

                    // looking for seed target, 1 mismatch is allowed for these 2 seeds
                    // which means seq1 and seq2 at least should take 1 perfect seed match
                    seed.clear();
                    for( i=0; (i=seq1[ii].find(kp.adapter_index1, i)) != string::npos; ++i )
                        seed.push_back( i );
                    // for SE data, in case there is a error in the head of adapter, using index3 to increase sensitivity
                    for( i=OFFSET_INDEX3; (i=seq1[ii].find(kp.adapter_index3, i)) != string::npos; ++i )
                        seed.push_back( i-OFFSET_INDEX3 );

                    sort( seed.begin(), seed.end() );

                    last_seed = impossible_seed;	// a position which cannot be in seed
                    for( it=seed.begin(); it!=seed.end(); ++it ) {
                        if( *it != last_seed ) {
                        // as there maybe the same value in seq1_seed and seq2_seed,
                        // use this to avoid re-calculate that pos
                            if( check_mismatch_dynamic_SE( seq1[ii], *it, kp ) )
                                break;
                            last_seed = *it;
                        }
                    }
                    if( it != seed.end() ) {	// adapter found
                        ++ real_adapter[tn];
                        if( *it >= kp.min_length )	{
                            seq1[ii].resize(  *it );
                            qual1[ii].resize( *it );
                        } else {	// drop this read as its length is not enough
                            ++ dropped[tn];
                            continue;
                        }
                    } else {	// seed not found, now check the tail 2 or 1, if perfect match, drop these 2
                        i = seq1[ii].length() - 2;
                        p = seq1[ii].c_str();
                        if( p[i]==kp.adapter_r1[0] && p[i+1]==kp.adapter_r1[1] ) {
                            if( i < kp.min_length ) {
                                ++ dropped[tn];
                                continue;
                            }
                            seq1[ii].resize(  i );
                            qual1[ii].resize( i );

                            ++ tail_adapter[tn];
                        } else {	// tail 2 is not good, check tail 1
                            ++ i;
                            if( p[i] == kp.adapter_r1[0] ) {
                                if( i < kp.min_length ) {
                                    ++ dropped[tn];
                                    continue;
                                }
                                seq1[ii].resize(  i );
                                qual1[ii].resize( i );

                                ++ tail_adapter[tn];
                            }
                        }
                    }

                    //check if there is any white space in the IDs; if so, remove all the data after the whitespace
                    j = id1[ii].size();
                    p = id1[ii].c_str();
                    for( i=1; i!=j; ++i ) {
                        if( p[i]==' ' || p[i]=='\t' ) {	// white space, then trim ID
                            id1[ii].resize( i );
                            break;
                        }
                    }

                    b1stored[tn] += sprintf( buffer1[tn]+b1stored[tn], "%s\n%s\n+\n%s\n",
                                            id1[ii].c_str(), seq1[ii].c_str(), qual1[ii].c_str() );
                }
            } // parallel body
            // write output and update fastq statistics
            for( unsigned int i=0; i!=kp.thread; ++i ) {
                fout1 << buffer1[i];
            }
            line += loaded;
            cerr << '\r' << line << " reads loaded";

            if( fq1.eof() ) break;
        }

        fq1.close();
    }

	fout1.close();
	cerr << "\rDone: " << line << " lines processed.\n";

	// write trim.log
    base = kp.outpre;
    base += ".trim.log";
	ofstream fout( base );
	if( fout.fail() ) { 
		cerr << "\033[1;34mError: cannot write log file!\033[0m\n";
		return 105;
	}
	int dropped_all=0, real_all=0, tail_all=0;
	for( unsigned int i=0; i!=kp.thread; ++i ) {
		dropped_all += dropped[i];
		real_all += real_adapter[i];
		tail_all += tail_adapter[i];
	}
	fout << "Total: "    << line        << '\n'
		 << "Dropped : " << dropped_all << '\n'
		 << "Aadaptor: " << real_all	<< '\n'
		 << "Tail Hit: " << tail_all	<< '\n';
	fout.close();

	//free memory
	for(unsigned int i=0; i!=kp.thread; ++i) {
		delete buffer1[i];
	}
	delete [] buffer1;

	return 0;
}

